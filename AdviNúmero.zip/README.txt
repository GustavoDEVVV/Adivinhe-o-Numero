O jogo consiste em dois modos relacionados a adivinhações de números:

Advinhe o Número:
haverá um número secreto entre 1 e 1000, o jogador deve descobrir o número em até 10 tentativas, para o auxilio, o jogo dirá se o número secreto é maior ou menor que o chute anterior.

Advinhe o Código:
haverá um codigo secreto de 3 digitos, o jogador deve digitar 3 números separadamente (apertando ENTER) e o jogo dará dicas se algum dos números está no codigo.