#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <time.h>
int op = 0;
int main();

int numero() {
    int numSec, chute, cont;
    srand(time(0));
    numSec = rand() % 1000 + 1;
    cont = 10;

	// printf("%d", numSec);	//descomente aqui para ver o numero
    while (chute != numSec && cont != 0) {
        printf("Digite um n�mero entre 1 e 1000: ");
        scanf("%d", &chute);

        if (chute == numSec) {
            int tryAct = 10 - cont + 1;
            printf("Acertou em %d tentativas!\n", tryAct);
            system("PAUSE");
        } else if (chute > numSec) {
            cont = cont - 1;
            if (cont == 0) {
                printf("Jogo encerrado, o n�mero secreto �: %d\n", numSec);
            } else {
                printf("Errou... O n�mero secreto � menor. Voc� tem mais %d chances\n", cont);
            }
        } else if (chute < numSec) {
            cont = cont - 1;
            if (cont == 0) {
                printf("Jogo encerrado, o n�mero secreto �: %d\n", numSec);
                system("PAUSE");
                break;
            } else {
                printf("Errou... O n�mero secreto � maior. Voc� tem mais %d chances\n", cont);
            }
        }
    }
     system("PAUSE");
    return 0;
}

int codigo(){
    int codSec[3], chute[3], i, acerto = 0;

    srand(time(0));
    codSec[0] = rand() % 10;
    codSec[1] = rand() % 10;
    codSec[2] = rand() % 10;
    //printf("%d %d %d\n", codSec[0], codSec[1], codSec[2]); //descomente aqui para ver o codigo
    while(acerto != 1){

    printf("Digite 3 n�meros de 0 a 9 um de cada vez, apertando enter entre eles:\n");
    for (i = 0; i < 3; i++){
    	printf("N�mero %d: ", i + 1);
        scanf("%d", &chute[i]);
        if (chute[i] > 9 || chute[i] < 0){
			printf("N�mero inv�lido, digite um n�mero entre 0 e 9\n");
			i--;
		}
	}

    if (chute[0] == codSec[0] && chute[1] == codSec[1] && chute[2] == codSec[2]) {
        printf("Todos os n�meros certos na posi��o certa.\n");
        acerto = 1; 
	} 
	// tive que fazer um codigo com tantos if's para resolver um bug que ele n�o informava corretamente
	else if ((chute[0] == codSec[0] || chute[0] == codSec[1] || chute[0] == codSec[2]) &&
               (chute[1] == codSec[0] || chute[1] == codSec[2]) &&
               (chute[2] == codSec[0] || chute[2] == codSec[1])) {
        printf("Todos os n�meros certos, mas nas posi��es erradas.\n");		//propositalmente n�o informa qual est� em posi��o correta
	} else if ((chute[0] == codSec[1] || chute[0] == codSec[2]) &&
               (chute[1] == codSec[0] || chute[1] == codSec[1] || chute[1] == codSec[2]) &&
               (chute[2] == codSec[0] || chute[2] == codSec[1])) {
        printf("Todos os n�meros certos, mas nas posi��es erradas.\n");		//propositalmente n�o informa qual est� em posi��o correta
	} else if ((chute[0] == codSec[1] || chute[0] == codSec[2]) &&
               (chute[1] == codSec[0] || chute[1] == codSec[2]) &&
               (chute[2] == codSec[0] || chute[2] == codSec[1] || chute[2] == codSec[2])) {
        printf("Todos os n�meros certos, mas nas posi��es erradas.\n");		//propositalmente n�o informa qual est� em posi��o correta
	} else if ((chute[0] == codSec[0] && chute[1] == codSec[1]) ||
			  (chute[0] == codSec[0] && chute[2] == codSec[2]) ||
              (chute[1] == codSec[1] && chute[2] == codSec[2])) {
        printf("Dois n�meros certos na posi��o certa.\n");
    } else if (chute[0] == codSec[0] || chute[1] == codSec[1] || chute[2] == codSec[2]) {
        printf("Um n�mero certo na posi��o certa.\n");
    } else if ((chute[0] == codSec[1] || chute[0] == codSec[2] || chute[1] == codSec[0] ||
                chute[1] == codSec[2] || chute[2] == codSec[0] || chute[2] == codSec[1])) {
        printf("Um n�mero certo na posi��o errada.\n");
    } else if ((chute[0] == codSec[1] && chute[1] == codSec[0]) ||
               (chute[0] == codSec[2] && chute[2] == codSec[0]) ||
               (chute[1] == codSec[0] && chute[0] == codSec[1]) ||
               (chute[1] == codSec[2] && chute[2] == codSec[1]) ||
               (chute[2] == codSec[0] && chute[0] == codSec[2]) ||
               (chute[2] == codSec[1] && chute[1] == codSec[2])) {
        printf("Dois n�meros certos na posi��o errada.\n");
    } else {
        printf("Nenhum n�mero certo.\n");
    }
	}
	system("PAUSE");
    return 0;
}

int menu(){
	setlocale(LC_ALL, "Portuguese");
	system("CLS");
	printf("======================================\n");
	printf("		 AdviN�mero			\n");
	printf("======================================\n");
	printf("	  Digite sua op��o:		\n");
	printf("	 1: Advinhe o n�mero	\n");
	printf("	 2: Advinhe o c�digo	\n");
	printf("	 3: Sair do Jogo		\n");
	printf("======================================\n");
	printf("Op��o: ");
	scanf("%d", &op);
	
	
	switch(op){
	case 1:
		system("CLS");
		numero();
		main(op);
		break;
	case 2:
		system("CLS");
		codigo();
		main(op);
		break;
	case 3:
		system("CLS");
		main(op);
		break;
	default:
		printf("Op��o inv�lida!\n");
		system("pause");
		system("CLS");
	}
	return 1;
}
int main(){
	while (op != 3){
		menu();
	} if (op == 3){
		exit(0);
	}
	
	return 0;
}